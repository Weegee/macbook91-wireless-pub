// SPDX-License-Identifier: GPL-2.0-or-later
/*
 *
 *  Bluetooth HCI UART driver for Broadcom devices
 *
 *  Copyright (C) 2015  Intel Corporation
 */

#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/skbuff.h>
#include <linux/firmware.h>
#include <linux/module.h>
#include <linux/acpi.h>
#include <linux/of.h>
#include <linux/of_irq.h>
#include <linux/property.h>
#include <linux/platform_data/x86/apple.h>
#include <linux/platform_device.h>
#include <linux/regulator/consumer.h>
#include <linux/clk.h>
#include <linux/gpio/consumer.h>
#include <linux/gpio/machine.h>
#include <linux/tty.h>
#include <linux/interrupt.h>
#include <linux/dmi.h>
#include <linux/pm_runtime.h>
#include <linux/serdev.h>

#include <net/bluetooth/bluetooth.h>
#include <net/bluetooth/hci_core.h>

#include "btbcm.h"
#include "hci_uart.h"

#define BCM_NULL_PKT 0x00
#define BCM_NULL_SIZE 0

#define BCM_LM_DIAG_PKT 0x07
#define BCM_LM_DIAG_SIZE 63

#define BCM_TYPE49_PKT 0x31
#define BCM_TYPE49_SIZE 0

#define BCM_TYPE52_PKT 0x34
#define BCM_TYPE52_SIZE 0

#define BCM_AUTOSUSPEND_DELAY	5000 /* default autosleep delay */

#define BCM_NUM_SUPPLIES 2

/**
 * struct bcm_device_data - device specific data
 * @no_early_set_baudrate: Disallow set baudrate before driver setup()
 * @drive_rts_on_open: drive RTS signal on ->open() when platform requires it
 * @no_uart_clock_set: UART clock set command for >3Mbps mode is unavailable
 * @max_autobaud_speed: max baudrate supported by device in autobaud mode
 * @max_speed: max baudrate supported
 */
struct bcm_device_data {
	bool	no_early_set_baudrate;
	bool	drive_rts_on_open;
	bool	no_uart_clock_set;
	u32	max_autobaud_speed;
	u32	max_speed;
};

/**
 * struct bcm_device - device driver resources
 * @serdev_hu: HCI UART controller struct
 * @list: bcm_device_list node
 * @dev: physical UART slave
 * @name: device name logged by bt_dev_*() functions
 * @device_wakeup: BT_WAKE pin,
 *	assert = Bluetooth device must wake up or remain awake,
 *	deassert = Bluetooth device may sleep when sleep criteria are met
 * @shutdown: BT_REG_ON pin,
 *	power up or power down Bluetooth device internal regulators
 * @reset: BT_RST_N pin,
 *	active low resets the Bluetooth logic core
 * @set_device_wakeup: callback to toggle BT_WAKE pin
 *	either by accessing @device_wakeup or by calling @btlp
 * @set_shutdown: callback to toggle BT_REG_ON pin
 *	either by accessing @shutdown or by calling @btpu/@btpd
 * @btlp: Apple ACPI method to toggle BT_WAKE pin ("Bluetooth Low Power")
 * @btpu: Apple ACPI method to drive BT_REG_ON pin high ("Bluetooth Power Up")
 * @btpd: Apple ACPI method to drive BT_REG_ON pin low ("Bluetooth Power Down")
 * @gpio_count: internal counter for GPIO resources associated with ACPI device
 * @gpio_int_idx: index in _CRS for GpioInt() resource
 * @txco_clk: external reference frequency clock used by Bluetooth device
 * @lpo_clk: external LPO clock used by Bluetooth device
 * @supplies: VBAT and VDDIO supplies used by Bluetooth device
 * @res_enabled: whether clocks and supplies are prepared and enabled
 * @init_speed: default baudrate of Bluetooth device;
 *	the host UART is initially set to this baudrate so that
 *	it can configure the Bluetooth device for @oper_speed
 * @oper_speed: preferred baudrate of Bluetooth device;
 *	set to 0 if @init_speed is already the preferred baudrate
 * @irq: interrupt triggered by HOST_WAKE_BT pin
 * @irq_active_low: whether @irq is active low
 * @irq_acquired: flag to show if IRQ handler has been assigned
 * @hu: pointer to HCI UART controller struct,
 *	used to disable flow control during runtime suspend and system sleep
 * @is_suspended: whether flow control is currently disabled
 * @no_early_set_baudrate: don't set_baudrate before setup()
 * @drive_rts_on_open: drive RTS signal on ->open() when platform requires it
 * @no_uart_clock_set: UART clock set command for >3Mbps mode is unavailable
 * @pcm_int_params: keep the initial PCM configuration
 * @use_autobaud_mode: start Bluetooth device in autobaud mode
 * @max_autobaud_speed: max baudrate supported by device in autobaud mode
 */
struct bcm_device {
	/* Must be the first member, hci_serdev.c expects this. */
	struct hci_uart		serdev_hu;
	struct list_head	list;

	struct device		*dev;

	const char		*name;
	struct gpio_desc	*device_wakeup;
	struct gpio_desc	*shutdown;
	struct gpio_desc	*reset;
	int			(*set_device_wakeup)(struct bcm_device *, bool);
	int			(*set_shutdown)(struct bcm_device *, bool);
#ifdef CONFIG_ACPI
	acpi_handle		btlp, btpu, btpd;
	int			gpio_count;
	int			gpio_int_idx;
#endif

	struct clk		*txco_clk;
	struct clk		*lpo_clk;
	struct regulator_bulk_data supplies[BCM_NUM_SUPPLIES];
	bool			res_enabled;

	u32			init_speed;
	u32			oper_speed;
	int			irq;
	bool			irq_active_low;
	bool			irq_acquired;

#ifdef CONFIG_PM
	struct hci_uart		*hu;
	bool			is_suspended;
#endif
	bool			no_early_set_baudrate;
	bool			drive_rts_on_open;
	bool			no_uart_clock_set;
	bool			use_autobaud_mode;
	bool			le_adv_type_fixup;
	bool			no_patchram;
	u8			pcm_int_params[5];
	u32			max_autobaud_speed;
};

/* generic bcm uart resources */
struct bcm_data {
	struct sk_buff		*rx_skb;
	struct sk_buff_head	txq;

	struct bcm_device	*dev;
	bool			le_adv_type_fixup;	/* from dev, see bcm_open() */
};

/* List of BCM BT UART devices */
static DEFINE_MUTEX(bcm_device_lock);
static LIST_HEAD(bcm_device_list);

static int irq_polarity = -1;
module_param(irq_polarity, int, 0444);
MODULE_PARM_DESC(irq_polarity, "IRQ polarity 0: active-high 1: active-low");

static bool apple_patchram;
module_param(apple_patchram, bool, 0644);
MODULE_PARM_DESC(apple_patchram, "Look for a firmware patch on Macs, which run their UART controllers on ROM firmware");

static inline void host_set_baudrate(struct hci_uart *hu, unsigned int speed)
{
	if (hu->serdev)
		serdev_device_set_baudrate(hu->serdev, speed);
	else
		hci_uart_set_baudrate(hu, speed);
}

static int bcm_set_baudrate(struct hci_uart *hu, unsigned int speed)
{
	struct hci_dev *hdev = hu->hdev;
	struct bcm_data *bcm = hu->priv;
	struct sk_buff *skb;
	struct bcm_update_uart_baud_rate param;

	if (speed > 3000000 && !bcm->dev->no_uart_clock_set) {
		struct bcm_write_uart_clock_setting clock;

		clock.type = BCM_UART_CLOCK_48MHZ;

		bt_dev_dbg(hdev, "Set Controller clock (%d)", clock.type);

		/* This Broadcom specific command changes the UART's controller
		 * clock for baud rate > 3000000.
		 */
		skb = __hci_cmd_sync(hdev, 0xfc45, 1, &clock, HCI_INIT_TIMEOUT);
		if (IS_ERR(skb)) {
			int err = PTR_ERR(skb);
			bt_dev_err(hdev, "BCM: failed to write clock (%d)",
				   err);
			return err;
		}

		kfree_skb(skb);
	}

	bt_dev_dbg(hdev, "Set Controller UART speed to %d bit/s", speed);

	param.zero = cpu_to_le16(0);
	param.baud_rate = cpu_to_le32(speed);

	/* This Broadcom specific command changes the UART's controller baud
	 * rate.
	 */
	skb = __hci_cmd_sync(hdev, 0xfc18, sizeof(param), &param,
			     HCI_INIT_TIMEOUT);
	if (IS_ERR(skb)) {
		int err = PTR_ERR(skb);
		bt_dev_err(hdev, "BCM: failed to write update baudrate (%d)",
			   err);
		return err;
	}

	kfree_skb(skb);

	return 0;
}

/* bcm_device_exists should be protected by bcm_device_lock */
static bool bcm_device_exists(struct bcm_device *device)
{
	struct list_head *p;

#ifdef CONFIG_PM
	/* Devices using serdev always exist */
	if (device && device->hu && device->hu->serdev)
		return true;
#endif

	list_for_each(p, &bcm_device_list) {
		struct bcm_device *dev = list_entry(p, struct bcm_device, list);

		if (device == dev)
			return true;
	}

	return false;
}

static int bcm_gpio_set_power(struct bcm_device *dev, bool powered)
{
	int err;

	if (powered && !dev->res_enabled) {
		/* Intel Macs use bcm_apple_get_resources() and don't
		 * have regulator supplies configured.
		 */
		if (dev->supplies[0].supply) {
			err = regulator_bulk_enable(BCM_NUM_SUPPLIES,
						    dev->supplies);
			if (err)
				return err;
		}

		/* LPO clock needs to be 32.768 kHz */
		err = clk_set_rate(dev->lpo_clk, 32768);
		if (err) {
			dev_err(dev->dev, "Could not set LPO clock rate\n");
			goto err_regulator_disable;
		}

		err = clk_prepare_enable(dev->lpo_clk);
		if (err)
			goto err_regulator_disable;

		err = clk_prepare_enable(dev->txco_clk);
		if (err)
			goto err_lpo_clk_disable;
	}

	err = dev->set_shutdown(dev, powered);
	if (err)
		goto err_txco_clk_disable;

	err = dev->set_device_wakeup(dev, powered);
	if (err)
		goto err_revert_shutdown;

	if (!powered && dev->res_enabled) {
		clk_disable_unprepare(dev->txco_clk);
		clk_disable_unprepare(dev->lpo_clk);

		/* Intel Macs use bcm_apple_get_resources() and don't
		 * have regulator supplies configured.
		 */
		if (dev->supplies[0].supply)
			regulator_bulk_disable(BCM_NUM_SUPPLIES,
					       dev->supplies);
	}

	/* wait for device to power on and come out of reset */
	usleep_range(100000, 120000);

	dev->res_enabled = powered;

	return 0;

err_revert_shutdown:
	dev->set_shutdown(dev, !powered);
err_txco_clk_disable:
	if (powered && !dev->res_enabled)
		clk_disable_unprepare(dev->txco_clk);
err_lpo_clk_disable:
	if (powered && !dev->res_enabled)
		clk_disable_unprepare(dev->lpo_clk);
err_regulator_disable:
	if (powered && !dev->res_enabled)
		regulator_bulk_disable(BCM_NUM_SUPPLIES, dev->supplies);
	return err;
}

#ifdef CONFIG_PM
static irqreturn_t bcm_host_wake(int irq, void *data)
{
	struct bcm_device *bdev = data;

	bt_dev_dbg(bdev, "Host wake IRQ");

	pm_runtime_get(bdev->dev);
	pm_runtime_put_autosuspend(bdev->dev);

	return IRQ_HANDLED;
}

static int bcm_request_irq(struct bcm_data *bcm)
{
	struct bcm_device *bdev = bcm->dev;
	int err;

	mutex_lock(&bcm_device_lock);
	if (!bcm_device_exists(bdev)) {
		err = -ENODEV;
		goto unlock;
	}

	if (bdev->irq <= 0) {
		err = -EOPNOTSUPP;
		goto unlock;
	}

	err = devm_request_irq(bdev->dev, bdev->irq, bcm_host_wake,
			       bdev->irq_active_low ? IRQF_TRIGGER_FALLING :
						      IRQF_TRIGGER_RISING,
			       "host_wake", bdev);
	if (err) {
		bdev->irq = err;
		goto unlock;
	}

	bdev->irq_acquired = true;

	device_init_wakeup(bdev->dev, true);

	pm_runtime_set_autosuspend_delay(bdev->dev,
					 BCM_AUTOSUSPEND_DELAY);
	pm_runtime_use_autosuspend(bdev->dev);
	pm_runtime_set_active(bdev->dev);
	pm_runtime_enable(bdev->dev);

unlock:
	mutex_unlock(&bcm_device_lock);

	return err;
}

static const struct bcm_set_sleep_mode default_sleep_params = {
	.sleep_mode = 1,	/* 0=Disabled, 1=UART, 2=Reserved, 3=USB */
	.idle_host = 2,		/* idle threshold HOST, in 300ms */
	.idle_dev = 2,		/* idle threshold device, in 300ms */
	.bt_wake_active = 1,	/* BT_WAKE active mode: 1 = high, 0 = low */
	.host_wake_active = 0,	/* HOST_WAKE active mode: 1 = high, 0 = low */
	.allow_host_sleep = 1,	/* Allow host sleep in SCO flag */
	.combine_modes = 1,	/* Combine sleep and LPM flag */
	.tristate_control = 0,	/* Allow tri-state control of UART tx flag */
	/* Irrelevant USB flags */
	.usb_auto_sleep = 0,
	.usb_resume_timeout = 0,
	.break_to_host = 0,
	.pulsed_host_wake = 1,
};

static int bcm_setup_sleep(struct hci_uart *hu)
{
	struct bcm_data *bcm = hu->priv;
	struct sk_buff *skb;
	struct bcm_set_sleep_mode sleep_params = default_sleep_params;

	sleep_params.host_wake_active = !bcm->dev->irq_active_low;

	skb = __hci_cmd_sync(hu->hdev, 0xfc27, sizeof(sleep_params),
			     &sleep_params, HCI_INIT_TIMEOUT);
	if (IS_ERR(skb)) {
		int err = PTR_ERR(skb);
		bt_dev_err(hu->hdev, "Sleep VSC failed (%d)", err);
		return err;
	}
	kfree_skb(skb);

	bt_dev_dbg(hu->hdev, "Set Sleep Parameters VSC succeeded");

	return 0;
}
#else
static inline int bcm_request_irq(struct bcm_data *bcm) { return 0; }
static inline int bcm_setup_sleep(struct hci_uart *hu) { return 0; }
#endif

static int bcm_set_diag(struct hci_dev *hdev, bool enable)
{
	struct hci_uart *hu = hci_get_drvdata(hdev);
	struct bcm_data *bcm = hu->priv;
	struct sk_buff *skb;

	if (!test_bit(HCI_RUNNING, &hdev->flags))
		return -ENETDOWN;

	skb = bt_skb_alloc(3, GFP_KERNEL);
	if (!skb)
		return -ENOMEM;

	skb_put_u8(skb, BCM_LM_DIAG_PKT);
	skb_put_u8(skb, 0xf0);
	skb_put_u8(skb, enable);

	skb_queue_tail(&bcm->txq, skb);
	hci_uart_tx_wakeup(hu);

	return 0;
}

static int bcm_open(struct hci_uart *hu)
{
	struct bcm_data *bcm;
	struct list_head *p;
	int err;

	bt_dev_dbg(hu->hdev, "hu %p", hu);

	if (!hci_uart_has_flow_control(hu))
		return -EOPNOTSUPP;

	bcm = kzalloc_obj(*bcm);
	if (!bcm)
		return -ENOMEM;

	skb_queue_head_init(&bcm->txq);

	hu->priv = bcm;

	mutex_lock(&bcm_device_lock);

	if (hu->serdev) {
		bcm->dev = serdev_device_get_drvdata(hu->serdev);
		goto out;
	}

	if (!hu->tty->dev)
		goto out;

	list_for_each(p, &bcm_device_list) {
		struct bcm_device *dev = list_entry(p, struct bcm_device, list);

		/* Retrieve saved bcm_device based on parent of the
		 * platform device (saved during device probe) and
		 * parent of tty device used by hci_uart
		 */
		if (hu->tty->dev->parent == dev->dev->parent) {
			bcm->dev = dev;
#ifdef CONFIG_PM
			dev->hu = hu;
#endif
			break;
		}
	}

out:
	if (bcm->dev) {
		/* Copied under bcm_device_lock: the receive path must not
		 * dereference bcm->dev, see bcm_recv().
		 */
		bcm->le_adv_type_fixup = bcm->dev->le_adv_type_fixup;

		if (bcm->dev->use_autobaud_mode)
			hci_uart_set_flow_control(hu, false);	/* Assert BT_UART_CTS_N */
		else if (bcm->dev->drive_rts_on_open)
			hci_uart_set_flow_control(hu, true);

		if (bcm->dev->use_autobaud_mode && bcm->dev->max_autobaud_speed)
			hu->init_speed = min(bcm->dev->oper_speed, bcm->dev->max_autobaud_speed);
		else
			hu->init_speed = bcm->dev->init_speed;

		/* If oper_speed is set, ldisc/serdev will set the baudrate
		 * before calling setup()
		 */
		if (!bcm->dev->no_early_set_baudrate && !bcm->dev->use_autobaud_mode)
			hu->oper_speed = bcm->dev->oper_speed;

		err = bcm_gpio_set_power(bcm->dev, true);

		if (bcm->dev->drive_rts_on_open)
			hci_uart_set_flow_control(hu, false);

		if (err)
			goto err_unset_hu;
	}

	mutex_unlock(&bcm_device_lock);
	return 0;

err_unset_hu:
#ifdef CONFIG_PM
	if (!hu->serdev)
		bcm->dev->hu = NULL;
#endif
	mutex_unlock(&bcm_device_lock);
	hu->priv = NULL;
	kfree(bcm);
	return err;
}

static int bcm_close(struct hci_uart *hu)
{
	struct bcm_data *bcm = hu->priv;
	struct bcm_device *bdev = NULL;
	int err;

	bt_dev_dbg(hu->hdev, "hu %p", hu);

	/* Protect bcm->dev against removal of the device or driver */
	mutex_lock(&bcm_device_lock);

	if (hu->serdev) {
		bdev = serdev_device_get_drvdata(hu->serdev);
	} else if (bcm_device_exists(bcm->dev)) {
		bdev = bcm->dev;
#ifdef CONFIG_PM
		bdev->hu = NULL;
#endif
	}

	if (bdev) {
		if (IS_ENABLED(CONFIG_PM) && bdev->irq_acquired) {
			devm_free_irq(bdev->dev, bdev->irq, bdev);
			device_init_wakeup(bdev->dev, false);
			pm_runtime_dont_use_autosuspend(bdev->dev);
			pm_runtime_disable(bdev->dev);
		}

		err = bcm_gpio_set_power(bdev, false);
		if (err)
			bt_dev_err(hu->hdev, "Failed to power down");
		else
			pm_runtime_set_suspended(bdev->dev);
	}
	mutex_unlock(&bcm_device_lock);

	skb_queue_purge(&bcm->txq);
	kfree_skb(bcm->rx_skb);
	kfree(bcm);

	hu->priv = NULL;
	return 0;
}

static int bcm_flush(struct hci_uart *hu)
{
	struct bcm_data *bcm = hu->priv;

	bt_dev_dbg(hu->hdev, "hu %p", hu);

	skb_queue_purge(&bcm->txq);

	return 0;
}

static int bcm_setup(struct hci_uart *hu)
{
	struct bcm_data *bcm = hu->priv;
	bool fw_load_done = false;
	bool use_autobaud_mode = (bcm->dev ? bcm->dev->use_autobaud_mode : 0);
	unsigned int speed, init_speed;
	bool apple, rom_only;
	int err;

	bt_dev_dbg(hu->hdev, "hu %p", hu);

	hu->hdev->set_diag = bcm_set_diag;
	hu->hdev->set_bdaddr = btbcm_set_bdaddr;

	/* The UART controllers of Intel Macs run on ROM firmware; macOS and
	 * Boot Camp load no patch for them, so there is none to look for.
	 * Set up the controller as after a patch, without re-initializing.
	 * no_patchram is set for Macs only (bcm_apple_get_resources()).
	 */
	apple = bcm->dev && bcm->dev->no_patchram;
	rom_only = apple && !apple_patchram;
	if (rom_only)
		fw_load_done = true;

	err = btbcm_initialize(hu->hdev, &fw_load_done, use_autobaud_mode);
	if (err)
		return err;

	if (!fw_load_done)
		return 0;

	/* Init speed if any */
	if (bcm->dev && bcm->dev->init_speed)
		speed = bcm->dev->init_speed;
	else if (hu->proto->init_speed)
		speed = hu->proto->init_speed;
	else
		speed = 0;

	if (speed)
		host_set_baudrate(hu, speed);
	init_speed = speed;

	/* Operational speed if any */
	if (hu->oper_speed)
		speed = hu->oper_speed;
	else if (bcm->dev && bcm->dev->oper_speed)
		speed = bcm->dev->oper_speed;
	else if (hu->proto->oper_speed)
		speed = hu->proto->oper_speed;
	else
		speed = 0;

	/* On Macs, nothing to change when the controller already runs at
	 * the operational speed (both are the ACPI 'baud' of 3 Mbit/s); the
	 * controller may refuse the command then (Command Disallowed).
	 */
	if (speed && !(apple && speed == init_speed)) {
		err = bcm_set_baudrate(hu, speed);
		if (!err)
			host_set_baudrate(hu, speed);
	}

	/* PCM parameters if provided */
	if (bcm->dev && bcm->dev->pcm_int_params[0] != 0xff) {
		struct bcm_set_pcm_int_params params;

		btbcm_read_pcm_int_params(hu->hdev, &params);

		memcpy(&params, bcm->dev->pcm_int_params, 5);
		btbcm_write_pcm_int_params(hu->hdev, &params);
	}

	/* Without a patch there is nothing to re-initialize. */
	if (rom_only)
		fw_load_done = false;

	err = btbcm_finalize(hu->hdev, &fw_load_done, use_autobaud_mode);
	if (err)
		return err;

	/* Some devices ship with the controller default address.
	 * Allow the bootloader to set a valid address through the
	 * device tree.
	 */
	if (hci_test_quirk(hu->hdev, HCI_QUIRK_INVALID_BDADDR))
		hci_set_quirk(hu->hdev, HCI_QUIRK_USE_BDADDR_PROPERTY);

	if (!bcm_request_irq(bcm))
		err = bcm_setup_sleep(hu);

	return err;
}

#define BCM_RECV_LM_DIAG \
	.type = BCM_LM_DIAG_PKT, \
	.hlen = BCM_LM_DIAG_SIZE, \
	.loff = 0, \
	.lsize = 0, \
	.maxlen = BCM_LM_DIAG_SIZE

#define BCM_RECV_NULL \
	.type = BCM_NULL_PKT, \
	.hlen = BCM_NULL_SIZE, \
	.loff = 0, \
	.lsize = 0, \
	.maxlen = BCM_NULL_SIZE

#define BCM_RECV_TYPE49 \
	.type = BCM_TYPE49_PKT, \
	.hlen = BCM_TYPE49_SIZE, \
	.loff = 0, \
	.lsize = 0, \
	.maxlen = BCM_TYPE49_SIZE

#define BCM_RECV_TYPE52 \
	.type = BCM_TYPE52_PKT, \
	.hlen = BCM_TYPE52_SIZE, \
	.loff = 0, \
	.lsize = 0, \
	.maxlen = BCM_TYPE52_SIZE

/* The BCM4350C0 UART controller of Intel Macs (ROM build 1532, no patch
 * for it in macOS or Boot Camp) sets bits 4 and 5 of the event type in
 * legacy LE Advertising Reports: on the MacBook9,1 268 of 434 reports of a
 * scan came as 0x10, 0x13, 0x14, 0x20, 0x22, 0x23, 0x24. The core drops
 * them as 'unknown advertising packet type', so LE devices are found and
 * reconnected late or not at all. The low three bits carry a valid type;
 * the reserved upper bits are cleared before the core sees the report.
 */
static void bcm_fixup_le_adv_report(struct sk_buff *skb)
{
	u8 *d = skb->data;
	unsigned int len = skb->len, off = 4;
	u8 num;

	if (len < 4 || d[0] != HCI_EV_LE_META ||
	    d[2] != HCI_EV_LE_ADVERTISING_REPORT)
		return;

	/* Each report: type, address type, address[6], data length, data,
	 * RSSI.
	 */
	for (num = d[3]; num && off + 10 <= len; num--) {
		u8 type = d[off];

		if ((type & ~0x07) && (type & 0x07) <= LE_ADV_SCAN_RSP)
			d[off] = type & 0x07;
		off += 10 + d[off + 8];
	}
}

static int bcm_recv_event(struct hci_dev *hdev, struct sk_buff *skb)
{
	struct hci_uart *hu = hci_get_drvdata(hdev);
	struct bcm_data *bcm = hu ? hu->priv : NULL;

	if (bcm && bcm->le_adv_type_fixup)
		bcm_fixup_le_adv_report(skb);

	return hci_recv_frame(hdev, skb);
}

static const struct h4_recv_pkt bcm_recv_pkts[] = {
	{ H4_RECV_ACL,      .recv = hci_recv_frame },
	{ H4_RECV_SCO,      .recv = hci_recv_frame },
	{ H4_RECV_EVENT,    .recv = bcm_recv_event },
	{ H4_RECV_ISO,      .recv = hci_recv_frame },
	{ BCM_RECV_LM_DIAG, .recv = hci_recv_diag  },
	{ BCM_RECV_NULL,    .recv = hci_recv_diag  },
	{ BCM_RECV_TYPE49,  .recv = hci_recv_diag  },
	{ BCM_RECV_TYPE52,  .recv = hci_recv_diag  },
};

static int bcm_recv(struct hci_uart *hu, const void *data, int count)
{
	struct bcm_data *bcm = hu->priv;

	if (!test_bit(HCI_UART_REGISTERED, &hu->flags))
		return -EUNATCH;

	bcm->rx_skb = h4_recv_buf(hu, bcm->rx_skb, data, count,
				  bcm_recv_pkts, ARRAY_SIZE(bcm_recv_pkts));
	if (IS_ERR(bcm->rx_skb)) {
		int err = PTR_ERR(bcm->rx_skb);
		bt_dev_err(hu->hdev, "Frame reassembly failed (%d)", err);
		bcm->rx_skb = NULL;
		return err;
	} else if (!bcm->rx_skb) {
		/* Delay auto-suspend when receiving completed packet */
		mutex_lock(&bcm_device_lock);
		if (bcm->dev && bcm_device_exists(bcm->dev)) {
			pm_runtime_get(bcm->dev->dev);
			pm_runtime_put_autosuspend(bcm->dev->dev);
		}
		mutex_unlock(&bcm_device_lock);
	}

	return count;
}

static int bcm_enqueue(struct hci_uart *hu, struct sk_buff *skb)
{
	struct bcm_data *bcm = hu->priv;

	bt_dev_dbg(hu->hdev, "hu %p skb %p", hu, skb);

	/* Prepend skb with frame type */
	memcpy(skb_push(skb, 1), &hci_skb_pkt_type(skb), 1);
	skb_queue_tail(&bcm->txq, skb);

	return 0;
}

static struct sk_buff *bcm_dequeue(struct hci_uart *hu)
{
	struct bcm_data *bcm = hu->priv;
	struct sk_buff *skb = NULL;
	struct bcm_device *bdev = NULL;

	mutex_lock(&bcm_device_lock);

	if (bcm_device_exists(bcm->dev)) {
		bdev = bcm->dev;
		pm_runtime_get_sync(bdev->dev);
		/* Shall be resumed here */
	}

	skb = skb_dequeue(&bcm->txq);

	if (bdev)
		pm_runtime_put_autosuspend(bdev->dev);

	mutex_unlock(&bcm_device_lock);

	return skb;
}

#ifdef CONFIG_PM
static int bcm_suspend_device(struct device *dev)
{
	struct bcm_device *bdev = dev_get_drvdata(dev);
	int err;

	bt_dev_dbg(bdev, "");

	if (!bdev->is_suspended && bdev->hu) {
		hci_uart_set_flow_control(bdev->hu, true);

		/* Once this returns, driver suspends BT via GPIO */
		bdev->is_suspended = true;
	}

	/* Suspend the device */
	err = bdev->set_device_wakeup(bdev, false);
	if (err) {
		if (bdev->is_suspended && bdev->hu) {
			bdev->is_suspended = false;
			hci_uart_set_flow_control(bdev->hu, false);
		}
		return -EBUSY;
	}

	bt_dev_dbg(bdev, "suspend, delaying 15 ms");
	msleep(15);

	return 0;
}

static int bcm_resume_device(struct device *dev)
{
	struct bcm_device *bdev = dev_get_drvdata(dev);
	int err;

	bt_dev_dbg(bdev, "");

	err = bdev->set_device_wakeup(bdev, true);
	if (err) {
		dev_err(dev, "Failed to power up\n");
		return err;
	}

	bt_dev_dbg(bdev, "resume, delaying 15 ms");
	msleep(15);

	/* When this executes, the device has woken up already */
	if (bdev->is_suspended && bdev->hu) {
		bdev->is_suspended = false;

		hci_uart_set_flow_control(bdev->hu, false);
	}

	return 0;
}
#endif

#ifdef CONFIG_PM_SLEEP
/* suspend callback */
static int bcm_suspend(struct device *dev)
{
	struct bcm_device *bdev = dev_get_drvdata(dev);
	int error;

	bt_dev_dbg(bdev, "suspend: is_suspended %d", bdev->is_suspended);

	/*
	 * When used with a device instantiated as platform_device, bcm_suspend
	 * can be called at any time as long as the platform device is bound,
	 * so it should use bcm_device_lock to protect access to hci_uart
	 * and device_wake-up GPIO.
	 */
	mutex_lock(&bcm_device_lock);

	if (!bdev->hu)
		goto unlock;

	if (pm_runtime_active(dev))
		bcm_suspend_device(dev);

	if (device_may_wakeup(dev) && bdev->irq > 0) {
		error = enable_irq_wake(bdev->irq);
		if (!error)
			bt_dev_dbg(bdev, "BCM irq: enabled");
	}

unlock:
	mutex_unlock(&bcm_device_lock);

	return 0;
}

/* resume callback */
static int bcm_resume(struct device *dev)
{
	struct bcm_device *bdev = dev_get_drvdata(dev);
	int err = 0;

	bt_dev_dbg(bdev, "resume: is_suspended %d", bdev->is_suspended);

	/*
	 * When used with a device instantiated as platform_device, bcm_resume
	 * can be called at any time as long as platform device is bound,
	 * so it should use bcm_device_lock to protect access to hci_uart
	 * and device_wake-up GPIO.
	 */
	mutex_lock(&bcm_device_lock);

	if (!bdev->hu)
		goto unlock;

	if (device_may_wakeup(dev) && bdev->irq > 0) {
		disable_irq_wake(bdev->irq);
		bt_dev_dbg(bdev, "BCM irq: disabled");
	}

	err = bcm_resume_device(dev);

unlock:
	mutex_unlock(&bcm_device_lock);

	if (!err) {
		pm_runtime_disable(dev);
		pm_runtime_set_active(dev);
		pm_runtime_enable(dev);
	}

	return 0;
}
#endif

/* Some firmware reports an IRQ which does not work (wrong pin in fw table?) */
static struct gpiod_lookup_table irq_on_int33fc02_pin17_gpios = {
	.dev_id = "serial0-0",
	.table = {
		GPIO_LOOKUP("INT33FC:02", 17, "host-wakeup-alt", GPIO_ACTIVE_HIGH),
		{ }
	},
};

static const struct dmi_system_id bcm_broken_irq_dmi_table[] = {
	{
		.ident = "Acer Iconia One 7 B1-750",
		.matches = {
			DMI_MATCH(DMI_SYS_VENDOR, "Insyde"),
			DMI_MATCH(DMI_PRODUCT_NAME, "VESPA2"),
		},
		.driver_data = &irq_on_int33fc02_pin17_gpios,
	},
	{
		.ident = "Asus TF103C",
		.matches = {
			DMI_MATCH(DMI_SYS_VENDOR, "ASUSTeK COMPUTER INC."),
			DMI_MATCH(DMI_PRODUCT_NAME, "TF103C"),
		},
		.driver_data = &irq_on_int33fc02_pin17_gpios,
	},
	{
		.ident = "Lenovo Yoga Tablet 2 830F/L / 1050F/L",
		.matches = {
			DMI_MATCH(DMI_SYS_VENDOR, "Intel Corp."),
			DMI_MATCH(DMI_PRODUCT_NAME, "VALLEYVIEW C0 PLATFORM"),
			DMI_MATCH(DMI_BOARD_NAME, "BYT-T FFD8"),
			/* Partial match on beginning of BIOS version */
			DMI_MATCH(DMI_BIOS_VERSION, "BLADE_21"),
		},
		.driver_data = &irq_on_int33fc02_pin17_gpios,
	},
	{
		.ident = "Meegopad T08",
		.matches = {
			DMI_EXACT_MATCH(DMI_BOARD_VENDOR,
					"To be filled by OEM."),
			DMI_EXACT_MATCH(DMI_BOARD_NAME, "T3 MRD"),
			DMI_EXACT_MATCH(DMI_BOARD_VERSION, "V1.1"),
		},
	},
	{ }
};

#ifdef CONFIG_ACPI
static const struct acpi_gpio_params first_gpio = { 0, 0, false };
static const struct acpi_gpio_params second_gpio = { 1, 0, false };
static const struct acpi_gpio_params third_gpio = { 2, 0, false };

static const struct acpi_gpio_mapping acpi_bcm_int_last_gpios[] = {
	{ "device-wakeup-gpios", &first_gpio, 1 },
	{ "shutdown-gpios", &second_gpio, 1 },
	{ "host-wakeup-gpios", &third_gpio, 1 },
	{ },
};

static const struct acpi_gpio_mapping acpi_bcm_int_first_gpios[] = {
	{ "host-wakeup-gpios", &first_gpio, 1 },
	{ "device-wakeup-gpios", &second_gpio, 1 },
	{ "shutdown-gpios", &third_gpio, 1 },
	{ },
};

static int bcm_resource(struct acpi_resource *ares, void *data)
{
	struct bcm_device *dev = data;
	struct acpi_resource_extended_irq *irq;
	struct acpi_resource_gpio *gpio;
	struct acpi_resource_uart_serialbus *sb;

	switch (ares->type) {
	case ACPI_RESOURCE_TYPE_EXTENDED_IRQ:
		irq = &ares->data.extended_irq;
		if (irq->polarity != ACPI_ACTIVE_LOW)
			dev_info(dev->dev, "ACPI Interrupt resource is active-high, this is usually wrong, treating the IRQ as active-low\n");
		dev->irq_active_low = true;
		break;

	case ACPI_RESOURCE_TYPE_GPIO:
		gpio = &ares->data.gpio;
		if (gpio->connection_type == ACPI_RESOURCE_GPIO_TYPE_INT) {
			dev->gpio_int_idx = dev->gpio_count;
			dev->irq_active_low = gpio->polarity == ACPI_ACTIVE_LOW;
		}
		dev->gpio_count++;
		break;

	case ACPI_RESOURCE_TYPE_SERIAL_BUS:
		sb = &ares->data.uart_serial_bus;
		if (sb->type == ACPI_RESOURCE_SERIAL_TYPE_UART) {
			dev->init_speed = sb->default_baud_rate;
			dev->oper_speed = 4000000;
		}
		break;

	default:
		break;
	}

	return 0;
}

static int bcm_apple_set_device_wakeup(struct bcm_device *dev, bool awake)
{
	if (ACPI_FAILURE(acpi_execute_simple_method(dev->btlp, NULL, !awake)))
		return -EIO;

	return 0;
}

static int bcm_apple_set_shutdown(struct bcm_device *dev, bool powered)
{
	if (ACPI_FAILURE(acpi_evaluate_object(powered ? dev->btpu : dev->btpd,
					      NULL, NULL, NULL)))
		return -EIO;

	return 0;
}

static int bcm_apple_get_resources(struct bcm_device *dev)
{
	struct acpi_device *adev = ACPI_COMPANION(dev->dev);
	const union acpi_object *obj;

	if (!adev ||
	    ACPI_FAILURE(acpi_get_handle(adev->handle, "BTLP", &dev->btlp)) ||
	    ACPI_FAILURE(acpi_get_handle(adev->handle, "BTPU", &dev->btpu)) ||
	    ACPI_FAILURE(acpi_get_handle(adev->handle, "BTPD", &dev->btpd)))
		return -ENODEV;

	if (!acpi_dev_get_property(adev, "baud", ACPI_TYPE_BUFFER, &obj) &&
	    obj->buffer.length == 8)
		dev->init_speed = *(u64 *)obj->buffer.pointer;

	dev->set_device_wakeup = bcm_apple_set_device_wakeup;
	dev->set_shutdown = bcm_apple_set_shutdown;
	dev->le_adv_type_fixup = true;
	dev->no_patchram = true;
	/* The controller starts at the ACPI 'baud' (3 Mbit/s, also the
	 * maximum of the LPSS UART) and refuses a speed change before its
	 * reset (Command Disallowed).
	 */
	dev->no_early_set_baudrate = true;

	return 0;
}
#else
static inline int bcm_apple_get_resources(struct bcm_device *dev)
{
	return -EOPNOTSUPP;
}
#endif /* CONFIG_ACPI */

static int bcm_gpio_set_device_wakeup(struct bcm_device *dev, bool awake)
{
	gpiod_set_value_cansleep(dev->device_wakeup, awake);
	return 0;
}

static int bcm_gpio_set_shutdown(struct bcm_device *dev, bool powered)
{
	gpiod_set_value_cansleep(dev->shutdown, powered);
	if (dev->reset)
		/*
		 * The reset line is asserted on powerdown and deasserted
		 * on poweron so the inverse of powered is used. Notice
		 * that the GPIO line BT_RST_N needs to be specified as
		 * active low in the device tree or similar system
		 * description.
		 */
		gpiod_set_value_cansleep(dev->reset, !powered);
	return 0;
}

/* Try a bunch of names for TXCO */
static struct clk *bcm_get_txco(struct device *dev)
{
	struct clk *clk;

	/* New explicit name */
	clk = devm_clk_get_optional(dev, "txco");
	if (clk)
		return clk;

	/* Deprecated name */
	clk = devm_clk_get_optional(dev, "extclk");
	if (clk)
		return clk;

	/* Original code used no name at all */
	return devm_clk_get_optional(dev, NULL);
}

static int bcm_get_resources(struct bcm_device *dev)
{
	const struct dmi_system_id *broken_irq_dmi_id;
	const char *irq_con_id = "host-wakeup";
	int err;

	dev->name = dev_name(dev->dev);

	if (x86_apple_machine && !bcm_apple_get_resources(dev))
		return 0;

	dev->txco_clk = bcm_get_txco(dev->dev);
	if (IS_ERR(dev->txco_clk))
		return PTR_ERR(dev->txco_clk);

	dev->lpo_clk = devm_clk_get_optional(dev->dev, "lpo");
	if (IS_ERR(dev->lpo_clk))
		return PTR_ERR(dev->lpo_clk);

	/* Check if we accidentally fetched the lpo clock twice */
	if (dev->lpo_clk && clk_is_match(dev->lpo_clk, dev->txco_clk)) {
		devm_clk_put(dev->dev, dev->txco_clk);
		dev->txco_clk = NULL;
	}

	dev->device_wakeup = devm_gpiod_get_optional(dev->dev, "device-wakeup",
						     GPIOD_OUT_LOW);
	if (IS_ERR(dev->device_wakeup))
		return PTR_ERR(dev->device_wakeup);

	dev->shutdown = devm_gpiod_get_optional(dev->dev, "shutdown",
						GPIOD_OUT_LOW);
	if (IS_ERR(dev->shutdown))
		return PTR_ERR(dev->shutdown);

	dev->reset = devm_gpiod_get_optional(dev->dev, "reset",
					     GPIOD_OUT_LOW);
	if (IS_ERR(dev->reset))
		return PTR_ERR(dev->reset);

	dev->set_device_wakeup = bcm_gpio_set_device_wakeup;
	dev->set_shutdown = bcm_gpio_set_shutdown;

	dev->supplies[0].supply = "vbat";
	dev->supplies[1].supply = "vddio";
	err = devm_regulator_bulk_get(dev->dev, BCM_NUM_SUPPLIES,
				      dev->supplies);
	if (err)
		return err;

	broken_irq_dmi_id = dmi_first_match(bcm_broken_irq_dmi_table);
	if (broken_irq_dmi_id && broken_irq_dmi_id->driver_data) {
		gpiod_add_lookup_table(broken_irq_dmi_id->driver_data);
		irq_con_id = "host-wakeup-alt";
		dev->irq_active_low = false;
		dev->irq = 0;
	}

	/* IRQ can be declared in ACPI table as Interrupt or GpioInt */
	if (dev->irq <= 0) {
		struct gpio_desc *gpio;

		gpio = devm_gpiod_get_optional(dev->dev, irq_con_id, GPIOD_IN);
		if (IS_ERR(gpio))
			return PTR_ERR(gpio);

		dev->irq = gpiod_to_irq(gpio);
	}

	if (broken_irq_dmi_id) {
		if (broken_irq_dmi_id->driver_data) {
			gpiod_remove_lookup_table(broken_irq_dmi_id->driver_data);
		} else {
			dev_info(dev->dev, "%s: Has a broken IRQ config, disabling IRQ support / runtime-pm\n",
				 broken_irq_dmi_id->ident);
			dev->irq = 0;
		}
	}

	dev_dbg(dev->dev, "BCM irq: %d\n", dev->irq);
	return 0;
}

#ifdef CONFIG_ACPI
static int bcm_acpi_probe(struct bcm_device *dev)
{
	LIST_HEAD(resources);
	const struct acpi_gpio_mapping *gpio_mapping = acpi_bcm_int_last_gpios;
	struct resource_entry *entry;
	int ret;

	/* Retrieve UART ACPI info */
	dev->gpio_int_idx = -1;
	ret = acpi_dev_get_resources(ACPI_COMPANION(dev->dev),
				     &resources, bcm_resource, dev);
	if (ret < 0)
		return ret;

	resource_list_for_each_entry(entry, &resources) {
		if (resource_type(entry->res) == IORESOURCE_IRQ) {
			dev->irq = entry->res->start;
			break;
		}
	}
	acpi_dev_free_resource_list(&resources);

	/* If the DSDT uses an Interrupt resource for the IRQ, then there are
	 * only 2 GPIO resources, we use the irq-last mapping for this, since
	 * we already have an irq the 3th / last mapping will not be used.
	 */
	if (dev->irq)
		gpio_mapping = acpi_bcm_int_last_gpios;
	else if (dev->gpio_int_idx == 0)
		gpio_mapping = acpi_bcm_int_first_gpios;
	else if (dev->gpio_int_idx == 2)
		gpio_mapping = acpi_bcm_int_last_gpios;
	else if (!x86_apple_machine)
		dev_warn(dev->dev, "Unexpected ACPI gpio_int_idx: %d\n",
			 dev->gpio_int_idx);

	/* Warn if our expectations are not met. Macs have no GPIO resources:
	 * power and wake are ACPI methods (bcm_apple_get_resources()).
	 */
	if (dev->gpio_count != (dev->irq ? 2 : 3) && !x86_apple_machine)
		dev_warn(dev->dev, "Unexpected number of ACPI GPIOs: %d\n",
			 dev->gpio_count);

	ret = devm_acpi_dev_add_driver_gpios(dev->dev, gpio_mapping);
	if (ret)
		return ret;

	if (irq_polarity != -1) {
		dev->irq_active_low = irq_polarity;
		dev_warn(dev->dev, "Overwriting IRQ polarity to active %s by module-param\n",
			 dev->irq_active_low ? "low" : "high");
	}

	return 0;
}
#else
static int bcm_acpi_probe(struct bcm_device *dev)
{
	return -EINVAL;
}
#endif /* CONFIG_ACPI */

static int bcm_of_probe(struct bcm_device *bdev)
{
	bdev->use_autobaud_mode = device_property_read_bool(bdev->dev,
							    "brcm,requires-autobaud-mode");
	device_property_read_u32(bdev->dev, "max-speed", &bdev->oper_speed);
	device_property_read_u8_array(bdev->dev, "brcm,bt-pcm-int-params",
				      bdev->pcm_int_params, 5);
	bdev->irq = of_irq_get_byname(bdev->dev->of_node, "host-wakeup");
	bdev->irq_active_low = irq_get_trigger_type(bdev->irq)
			     & (IRQ_TYPE_EDGE_FALLING | IRQ_TYPE_LEVEL_LOW);
	return 0;
}

static int bcm_probe(struct platform_device *pdev)
{
	struct bcm_device *dev;
	int ret;

	dev = devm_kzalloc(&pdev->dev, sizeof(*dev), GFP_KERNEL);
	if (!dev)
		return -ENOMEM;

	dev->dev = &pdev->dev;

	ret = platform_get_irq(pdev, 0);
	if (ret < 0)
		return ret;

	dev->irq = ret;

	/* Initialize routing field to an unused value */
	dev->pcm_int_params[0] = 0xff;

	if (has_acpi_companion(&pdev->dev)) {
		ret = bcm_acpi_probe(dev);
		if (ret)
			return ret;
	}

	ret = bcm_get_resources(dev);
	if (ret)
		return ret;

	platform_set_drvdata(pdev, dev);

	dev_info(&pdev->dev, "%s device registered.\n", dev->name);

	/* Place this instance on the device list */
	mutex_lock(&bcm_device_lock);
	list_add_tail(&dev->list, &bcm_device_list);
	mutex_unlock(&bcm_device_lock);

	ret = bcm_gpio_set_power(dev, false);
	if (ret)
		dev_err(&pdev->dev, "Failed to power down\n");

	return 0;
}

static void bcm_remove(struct platform_device *pdev)
{
	struct bcm_device *dev = platform_get_drvdata(pdev);

	mutex_lock(&bcm_device_lock);
	list_del(&dev->list);
	mutex_unlock(&bcm_device_lock);

	dev_info(&pdev->dev, "%s device unregistered.\n", dev->name);
}

static const struct hci_uart_proto bcm_proto = {
	.id		= HCI_UART_BCM,
	.name		= "Broadcom",
	.manufacturer	= 15,
	.init_speed	= 115200,
	.open		= bcm_open,
	.close		= bcm_close,
	.flush		= bcm_flush,
	.setup		= bcm_setup,
	.set_baudrate	= bcm_set_baudrate,
	.recv		= bcm_recv,
	.enqueue	= bcm_enqueue,
	.dequeue	= bcm_dequeue,
};

#ifdef CONFIG_ACPI

/* bcm43430a0/a1 BT does not support 48MHz UART clock, limit to 2000000 baud */
static struct bcm_device_data bcm43430_device_data = {
	.max_speed = 2000000,
};

static const struct acpi_device_id bcm_acpi_match[] = {
	{ .id = "BCM2E00" },
	{ .id = "BCM2E01" },
	{ .id = "BCM2E02" },
	{ .id = "BCM2E03" },
	{ .id = "BCM2E04" },
	{ .id = "BCM2E05" },
	{ .id = "BCM2E06" },
	{ .id = "BCM2E07" },
	{ .id = "BCM2E08" },
	{ .id = "BCM2E09" },
	{ .id = "BCM2E0A" },
	{ .id = "BCM2E0B" },
	{ .id = "BCM2E0C" },
	{ .id = "BCM2E0D" },
	{ .id = "BCM2E0E" },
	{ .id = "BCM2E0F" },
	{ .id = "BCM2E10" },
	{ .id = "BCM2E11" },
	{ .id = "BCM2E12" },
	{ .id = "BCM2E13" },
	{ .id = "BCM2E14" },
	{ .id = "BCM2E15" },
	{ .id = "BCM2E16" },
	{ .id = "BCM2E17" },
	{ .id = "BCM2E18" },
	{ .id = "BCM2E19" },
	{ .id = "BCM2E1A" },
	{ .id = "BCM2E1B" },
	{ .id = "BCM2E1C" },
	{ .id = "BCM2E1D" },
	{ .id = "BCM2E1F" },
	{ .id = "BCM2E20" },
	{ .id = "BCM2E21" },
	{ .id = "BCM2E22" },
	{ .id = "BCM2E23" },
	{ .id = "BCM2E24" },
	{ .id = "BCM2E25" },
	{ .id = "BCM2E26" },
	{ .id = "BCM2E27" },
	{ .id = "BCM2E28" },
	{ .id = "BCM2E29" },
	{ .id = "BCM2E2A" },
	{ .id = "BCM2E2B" },
	{ .id = "BCM2E2C" },
	{ .id = "BCM2E2D" },
	{ .id = "BCM2E2E" },
	{ .id = "BCM2E2F" },
	{ .id = "BCM2E30" },
	{ .id = "BCM2E31" },
	{ .id = "BCM2E32" },
	{ .id = "BCM2E33" },
	{ .id = "BCM2E34" },
	{ .id = "BCM2E35" },
	{ .id = "BCM2E36" },
	{ .id = "BCM2E37" },
	{ .id = "BCM2E38" },
	{ .id = "BCM2E39" },
	{ .id = "BCM2E3A" },
	{ .id = "BCM2E3B" },
	{ .id = "BCM2E3C" },
	{ .id = "BCM2E3D" },
	{ .id = "BCM2E3E" },
	{ .id = "BCM2E3F" },
	{ .id = "BCM2E40" },
	{ .id = "BCM2E41" },
	{ .id = "BCM2E42" },
	{ .id = "BCM2E43" },
	{ .id = "BCM2E44" },
	{ .id = "BCM2E45" },
	{ .id = "BCM2E46" },
	{ .id = "BCM2E47" },
	{ .id = "BCM2E48" },
	{ .id = "BCM2E49" },
	{ .id = "BCM2E4A" },
	{ .id = "BCM2E4B" },
	{ .id = "BCM2E4C" },
	{ .id = "BCM2E4D" },
	{ .id = "BCM2E4E" },
	{ .id = "BCM2E4F" },
	{ .id = "BCM2E50" },
	{ .id = "BCM2E51" },
	{ .id = "BCM2E52" },
	{ .id = "BCM2E53" },
	{ .id = "BCM2E54" },
	{ .id = "BCM2E55" },
	{ .id = "BCM2E56" },
	{ .id = "BCM2E57" },
	{ .id = "BCM2E58" },
	{ .id = "BCM2E59" },
	{ .id = "BCM2E5A" },
	{ .id = "BCM2E5B" },
	{ .id = "BCM2E5C" },
	{ .id = "BCM2E5D" },
	{ .id = "BCM2E5E" },
	{ .id = "BCM2E5F" },
	{ .id = "BCM2E60" },
	{ .id = "BCM2E61" },
	{ .id = "BCM2E62" },
	{ .id = "BCM2E63" },
	{ .id = "BCM2E64" },
	{ .id = "BCM2E65" },
	{ .id = "BCM2E66" },
	{ .id = "BCM2E67" },
	{ .id = "BCM2E68" },
	{ .id = "BCM2E69" },
	{ .id = "BCM2E6B" },
	{ .id = "BCM2E6D" },
	{ .id = "BCM2E6E" },
	{ .id = "BCM2E6F" },
	{ .id = "BCM2E70" },
	{ .id = "BCM2E71" },
	{ .id = "BCM2E72" },
	{ .id = "BCM2E73" },
	{ .id = "BCM2E74", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E75", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E76" },
	{ .id = "BCM2E77" },
	{ .id = "BCM2E78" },
	{ .id = "BCM2E79" },
	{ .id = "BCM2E7A" },
	{ .id = "BCM2E7B", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E7C" },
	{ .id = "BCM2E7D" },
	{ .id = "BCM2E7E" },
	{ .id = "BCM2E7F" },
	{ .id = "BCM2E80", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E81" },
	{ .id = "BCM2E82" },
	{ .id = "BCM2E83" },
	{ .id = "BCM2E84" },
	{ .id = "BCM2E85" },
	{ .id = "BCM2E86" },
	{ .id = "BCM2E87" },
	{ .id = "BCM2E88" },
	{ .id = "BCM2E89", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E8A" },
	{ .id = "BCM2E8B" },
	{ .id = "BCM2E8C" },
	{ .id = "BCM2E8D" },
	{ .id = "BCM2E8E" },
	{ .id = "BCM2E90" },
	{ .id = "BCM2E92" },
	{ .id = "BCM2E93" },
	{ .id = "BCM2E94", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E95" },
	{ .id = "BCM2E96" },
	{ .id = "BCM2E97" },
	{ .id = "BCM2E98" },
	{ .id = "BCM2E99", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E9A" },
	{ .id = "BCM2E9B", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2E9C" },
	{ .id = "BCM2E9D" },
	{ .id = "BCM2E9F", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2EA0" },
	{ .id = "BCM2EA1" },
	{ .id = "BCM2EA2", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2EA3", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2EA4", .driver_data = (long)&bcm43430_device_data }, /* bcm43455 */
	{ .id = "BCM2EA5" },
	{ .id = "BCM2EA6" },
	{ .id = "BCM2EA7" },
	{ .id = "BCM2EA8" },
	{ .id = "BCM2EA9" },
	{ .id = "BCM2EAA", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2EAB", .driver_data = (long)&bcm43430_device_data },
	{ .id = "BCM2EAC", .driver_data = (long)&bcm43430_device_data },
	{ }
};
MODULE_DEVICE_TABLE(acpi, bcm_acpi_match);
#endif

/* suspend and resume callbacks */
static const struct dev_pm_ops bcm_pm_ops = {
	SET_SYSTEM_SLEEP_PM_OPS(bcm_suspend, bcm_resume)
	SET_RUNTIME_PM_OPS(bcm_suspend_device, bcm_resume_device, NULL)
};

static struct platform_driver bcm_driver = {
	.probe = bcm_probe,
	.remove = bcm_remove,
	.driver = {
		.name = "hci_bcm",
		.acpi_match_table = ACPI_PTR(bcm_acpi_match),
		.pm = &bcm_pm_ops,
	},
};

static int bcm_serdev_probe(struct serdev_device *serdev)
{
	struct bcm_device *bcmdev;
	const struct bcm_device_data *data;
	int err;

	bcmdev = devm_kzalloc(&serdev->dev, sizeof(*bcmdev), GFP_KERNEL);
	if (!bcmdev)
		return -ENOMEM;

	bcmdev->dev = &serdev->dev;
#ifdef CONFIG_PM
	bcmdev->hu = &bcmdev->serdev_hu;
#endif
	bcmdev->serdev_hu.serdev = serdev;
	serdev_device_set_drvdata(serdev, bcmdev);

	/* Initialize routing field to an unused value */
	bcmdev->pcm_int_params[0] = 0xff;

	if (has_acpi_companion(&serdev->dev))
		err = bcm_acpi_probe(bcmdev);
	else
		err = bcm_of_probe(bcmdev);
	if (err)
		return err;

	err = bcm_get_resources(bcmdev);
	if (err)
		return err;

	if (!bcmdev->shutdown) {
		/* Macs power the controller through ACPI methods instead. */
		if (bcmdev->btpu)
			dev_dbg(&serdev->dev,
				"No reset GPIO, using default baud rate\n");
		else
			dev_warn(&serdev->dev,
				 "No reset resource, using default baud rate\n");
		bcmdev->oper_speed = bcmdev->init_speed;
	}

	err = bcm_gpio_set_power(bcmdev, false);
	if (err)
		dev_err(&serdev->dev, "Failed to power down\n");

	data = device_get_match_data(bcmdev->dev);
	if (data) {
		bcmdev->max_autobaud_speed = data->max_autobaud_speed;
		bcmdev->no_early_set_baudrate = data->no_early_set_baudrate;
		bcmdev->drive_rts_on_open = data->drive_rts_on_open;
		bcmdev->no_uart_clock_set = data->no_uart_clock_set;
		if (data->max_speed && bcmdev->oper_speed > data->max_speed)
			bcmdev->oper_speed = data->max_speed;
	}

	return hci_uart_register_device(&bcmdev->serdev_hu, &bcm_proto);
}

static void bcm_serdev_remove(struct serdev_device *serdev)
{
	struct bcm_device *bcmdev = serdev_device_get_drvdata(serdev);

	hci_uart_unregister_device(&bcmdev->serdev_hu);
}

#ifdef CONFIG_OF
static struct bcm_device_data bcm4354_device_data = {
	.no_early_set_baudrate = true,
};

static struct bcm_device_data bcm43438_device_data = {
	.drive_rts_on_open = true,
};

static struct bcm_device_data cyw4373a0_device_data = {
	.no_uart_clock_set = true,
};

static struct bcm_device_data cyw55572_device_data = {
	.max_autobaud_speed = 921600,
};

static const struct of_device_id bcm_bluetooth_of_match[] = {
	{ .compatible = "brcm,bcm20702a1" },
	{ .compatible = "brcm,bcm4329-bt" },
	{ .compatible = "brcm,bcm4330-bt" },
	{ .compatible = "brcm,bcm4334-bt" },
	{ .compatible = "brcm,bcm4345c5" },
	{ .compatible = "brcm,bcm43430a0-bt" },
	{ .compatible = "brcm,bcm43430a1-bt" },
	{ .compatible = "brcm,bcm43438-bt", .data = &bcm43438_device_data },
	{ .compatible = "brcm,bcm4349-bt", .data = &bcm43438_device_data },
	{ .compatible = "brcm,bcm43540-bt", .data = &bcm4354_device_data },
	{ .compatible = "brcm,bcm4335a0" },
	{ .compatible = "cypress,cyw4373a0-bt", .data = &cyw4373a0_device_data },
	{ .compatible = "infineon,cyw55572-bt", .data = &cyw55572_device_data },
	{ },
};
MODULE_DEVICE_TABLE(of, bcm_bluetooth_of_match);
#endif

static struct serdev_device_driver bcm_serdev_driver = {
	.probe = bcm_serdev_probe,
	.remove = bcm_serdev_remove,
	.driver = {
		.name = "hci_uart_bcm",
		.of_match_table = of_match_ptr(bcm_bluetooth_of_match),
		.acpi_match_table = ACPI_PTR(bcm_acpi_match),
		.pm = &bcm_pm_ops,
	},
};

int __init bcm_init(void)
{
	/* For now, we need to keep both platform device
	 * driver (ACPI generated) and serdev driver (DT).
	 */
	platform_driver_register(&bcm_driver);
	serdev_device_driver_register(&bcm_serdev_driver);

	return hci_uart_register_proto(&bcm_proto);
}

int __exit bcm_deinit(void)
{
	platform_driver_unregister(&bcm_driver);
	serdev_device_driver_unregister(&bcm_serdev_driver);

	return hci_uart_unregister_proto(&bcm_proto);
}
